package SDESImp;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SDESGUI extends JFrame {
    public static int[] P10 = {3, 5, 2, 7, 4, 10, 1, 9, 8, 6};
    public static int[] P8 = {6, 3, 7, 4, 8, 5, 10, 9};
    public static int[] P4 = {2, 4, 3, 1};
    public static int[] IP = {2, 6, 3, 1, 4, 8, 5, 7};
    public static int[] EP = {4, 1, 2, 3, 2, 3, 4, 1};
    public static int[] IP_inverse = {4, 1, 3, 5, 7, 2, 8, 6};
    public static int[][] sbox0 = {
            {1, 0, 3, 2},
            {3, 2, 1, 0},
            {0, 2, 1, 3},
            {3, 1, 0, 2}
    };
    public static int[][] sbox1 = {
            {0, 1, 2, 3},
            {2, 3, 1, 0},
            {3, 0, 1, 2},
            {2, 1, 0, 3}
    };
    private final JTextField plaintextField;
    private final JTextField keyField;
    private final JTextField ciphertextField;

    public SDESGUI() {
        // ���ô��ڱ���ʹ�С
        setTitle("������");
        setSize(700, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(true);

        // �������
        JLabel titleLabel = new JLabel("BINARY SDES");
        titleLabel.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 22));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setHorizontalAlignment(JLabel.CENTER);

        // ��������򼰱�ǩ
        JLabel plaintextLabel = new JLabel("��Ӧ������Ϊ:");
        plaintextLabel.setFont(new Font(Font.DIALOG, Font.PLAIN, 16));
        plaintextField = new JTextField(30);
        plaintextField.setFont(new Font(Font.DIALOG, Font.PLAIN, 16));

        // ��Կ����򼰱�ǩ
        JLabel keyLabel = new JLabel("��Ӧ����ԿΪ:");
        keyLabel.setFont(new Font(Font.DIALOG, Font.PLAIN, 16));
        keyField = new JTextField(30);
        keyField.setFont(new Font(Font.DIALOG, Font.PLAIN, 16));
        // ��������򼰱�ǩ
        JLabel ciphertextLabel = new JLabel("��Ӧ������Ϊ:");
        ciphertextLabel.setFont(new Font(Font.DIALOG, Font.PLAIN, 16));
        ciphertextField = new JTextField(30);
        ciphertextField.setFont(new Font(Font.DIALOG, Font.PLAIN, 16));
        // ���ܰ�ť
        JButton encryptButton = new JButton("����");
        encryptButton.setFont(new Font(Font.DIALOG, Font.PLAIN, 16));
        encryptButton.setBackground(Color.decode("#7041FE"));
        // ���ܰ�ť
        JButton decryptButton = new JButton("����");
        decryptButton.setFont(new Font(Font.DIALOG, Font.PLAIN, 16));
        decryptButton.setBackground(Color.decode("#7041FE"));
        Font textFieldFont = new Font(Font.DIALOG, Font.PLAIN, 16); // ���������С
        plaintextField.setFont(textFieldFont);
        keyField.setFont(textFieldFont);
        ciphertextField.setFont(textFieldFont);

        // ���������������
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        add(titleLabel, gbc);
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 1;
        add(plaintextLabel, gbc);
        gbc.gridx = 1;
        gbc.gridy = 1;
        add(plaintextField, gbc);
        gbc.gridx = 0;
        gbc.gridy = 2;
        add(keyLabel, gbc);
        gbc.gridx = 1;
        gbc.gridy = 2;
        add(keyField, gbc);
        gbc.gridx = 0;
        gbc.gridy = 3;
        add(ciphertextLabel, gbc);
        gbc.gridx = 1;
        gbc.gridy = 3;
        add(ciphertextField, gbc);
        // ���Ӱ�ť
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10)); // ������ť֮��ļ��
        buttonPanel.setBackground(Color.decode("#161E29"));
        buttonPanel.add(encryptButton);
        buttonPanel.add(decryptButton);
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 2;
        add(buttonPanel, gbc);
        // ���ô���λ��
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        int screenWidth = screenSize.width;
        int screenHeight = screenSize.height;
        int windowWidth = getWidth();
        int windowHeight = getHeight();
        int x = (screenWidth - windowWidth) / 2;
        int y = (screenHeight - windowHeight) / 2;
        setLocation(x, y);
        // ���ܰ�ť�¼�������
        encryptButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    //��ȡ����
                    String plaintext = plaintextField.getText();
                    String key = keyField.getText();
                    // ��������Ƿ�ֻ����0��1
                    if (!plaintext.matches("[01]+") || !key.matches("[01]+")) {
                        throw new IllegalArgumentException("������ֻ����0��1�Ķ��������֡�");
                    }

                    if (plaintext.length() != 8) {
                        throw new IllegalArgumentException("���ı���Ϊ8λ");
                    }

                    if (key.length() != 10) {
                        throw new IllegalArgumentException("��Կ����Ϊ10λ");
                    }

                    // ִ�м���
                    String[] keys = generateKey(key, P10, P8);
                    String k1 = keys[0];
                    String k2 = keys[1];
                    String ciphertext = encrypt(plaintext, k1, k2);

                    // �������Ŀ������
                    ciphertextField.setText(ciphertext);
                } catch (IllegalArgumentException ex) {
                    JOptionPane.showMessageDialog(SDESGUI.this, ex.getMessage(), "����", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        decryptButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    // ��ȡ����
                    String ciphertext = ciphertextField.getText();
                    String key = keyField.getText();
                    // ��������Ƿ�ֻ����0��1
                    if (!ciphertext.matches("[01]+") || !key.matches("[01]+")) {
                        throw new IllegalArgumentException("������ֻ����0��1�Ķ��������֡�");
                    }
                    if (ciphertext.length() != 8) {
                        throw new IllegalArgumentException("���ı���Ϊ8λ");
                    }
                    if (key.length() != 10) {
                        throw new IllegalArgumentException("��Կ����Ϊ10λ");
                    }

                    // ִ�н���
                    String[] keys = generateKey(key, P10, P8);
                    String k1 = keys[0];
                    String k2 = keys[1];
                    String plaintext = decrypt(ciphertext, k1, k2);

                    // �������Ŀ������
                    plaintextField.setText(plaintext);
                } catch (IllegalArgumentException ex) {
                    JOptionPane.showMessageDialog(SDESGUI.this, ex.getMessage(), "����", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        // ���ô��ڱ�����ɫ
        getContentPane().setBackground(Color.decode("#161E29"));
        // ����JTextField��JButton��JTextArea�ı�����ɫ
        plaintextField.setBackground(Color.decode("#7041FE"));
        keyField.setBackground(Color.decode("#7041FE"));
        ciphertextField.setBackground(Color.decode("#7041FE"));
        // ����JTextField��JButton��JTextArea�ı߿�
        Border border = BorderFactory.createLineBorder(Color.decode("#7041FE"));
        plaintextField.setBorder(border);
        keyField.setBorder(border);
        ciphertextField.setBorder(border);
        // ����JLabel��JTextField��JTextArea�е�������ɫ�ʹ�С
        plaintextLabel.setForeground(Color.WHITE);
        plaintextField.setForeground(Color.WHITE);
        keyLabel.setForeground(Color.WHITE);
        keyField.setForeground(Color.WHITE);
        ciphertextLabel.setForeground(Color.WHITE);
        ciphertextField.setForeground(Color.WHITE);
        plaintextLabel.setFont(new Font(Font.DIALOG, Font.BOLD, 15));
        plaintextField.setFont(new Font(Font.DIALOG, Font.BOLD, 15));
        keyLabel.setFont(new Font(Font.DIALOG, Font.BOLD, 15));
        keyField.setFont(new Font(Font.DIALOG, Font.BOLD, 15));
        ciphertextLabel.setFont(new Font(Font.DIALOG, Font.BOLD, 15));
        ciphertextField.setFont(new Font(Font.DIALOG, Font.BOLD, 15));
        // ����JButton�е�������ɫ�ʹ�С
        encryptButton.setForeground(Color.WHITE);
        decryptButton.setForeground(Color.WHITE);
        encryptButton.setFont(new Font(Font.DIALOG, Font.BOLD, 16));
        decryptButton.setFont(new Font(Font.DIALOG, Font.BOLD, 16));
    }

    // ͨ���û�����
    public static String permute(String inputStr, int[] table) {
        StringBuilder outputStr = new StringBuilder();
        for (int bitPosition : table) {
            outputStr.append(inputStr.charAt(bitPosition - 1));
        }
        return outputStr.toString();
    }

    // ѭ�����ƺ���
    public static String ls(String key, int n) {
        String leftHalf = key.substring(0, 5);
        String rightHalf = key.substring(5);
        String shiftedLeft = leftHalf.substring(n) + leftHalf.substring(0, n);
        String shiftedRight = rightHalf.substring(n) + rightHalf.substring(0, n);
        return shiftedLeft + shiftedRight;
    }

    // ����Կ����
    public static String[] generateKey(String k, int[] p10Table, int[] p8Table) {
        // ִ�� P10 �û�
        String p10Key = permute(k, p10Table);

        // �Խ���������Ʋ����� P8 �û����õ� K1
        String k1 = permute(ls(p10Key, 1), p8Table);

        // �ٴζ���һ������������Ʋ����� P8 �û����õ� K2
        String k2 = permute(ls(ls(p10Key, 1), 1), p8Table);

        return new String[]{k1, k2};
    }

    // S-DES �� F ����
    public static String F(String rightHalf, String k, int[] epTable, int[][] sbox0, int[][] sbox1, int[] p4Table) {
        // ���Ұ벿�ֽ��� E/P ��չ�û�
        String expanded = permute(rightHalf, epTable);

        // �Խ���� K1 ����������
        int xored = Integer.parseInt(expanded, 2) ^ Integer.parseInt(k, 2);
        String xoredStr = String.format("%08d", Integer.parseInt(Integer.toBinaryString(xored)));

        // �������Ϊ���飬������ S-box �����滻
        String s0Input = xoredStr.substring(0, 4);
        String s1Input = xoredStr.substring(4);

        // ���� S �й������в���
        int s0Row = Integer.parseInt(s0Input.charAt(0) + "" + s0Input.charAt(3), 2);
        int s0Col = Integer.parseInt(s0Input.substring(1, 3), 2);
        int s1Row = Integer.parseInt(s1Input.charAt(0) + "" + s1Input.charAt(3), 2);
        int s1Col = Integer.parseInt(s1Input.substring(1, 3), 2);

        String s0Output = String.format("%2s", Integer.toBinaryString(sbox0[s0Row][s0Col])).replace(' ', '0');
        String s1Output = String.format("%2s", Integer.toBinaryString(sbox1[s1Row][s1Col])).replace(' ', '0');

        // ��������������� P4 �û��õ����ս��
        String sOutput = permute(s0Output + s1Output, p4Table);

        return sOutput;
    }

    // ���ܹ���
    public static String encrypt(String p, String k1, String k2) {
        // ִ�г�ʼ�û�
        p = permute(p, IP);
        // �������� Fk����
        String l0 = p.substring(0, 4);
        String r0 = p.substring(4);
        String l1 = r0;
        // ��һ�ֵ� P4
        String fResult = F(r0, k1, EP, sbox0, sbox1, P4);
        // p4 �� L0 ���
        String r1 = String.format("%4s", Integer.toBinaryString(Integer.parseInt(l0, 2) ^ Integer.parseInt(fResult, 2))).replace(' ', '0');
        // �ڶ��ֵ� P4
        fResult = F(r1, k2, EP, sbox0, sbox1, P4);
        // p4 �� L1 ���
        String r2 = String.format("%4s", Integer.toBinaryString(Integer.parseInt(l1, 2) ^ Integer.parseInt(fResult, 2))).replace(' ', '0');
        // ���û������ؽ������� R2 �ұ� R1��
        return permute(r2 + r1, IP_inverse);
    }

    // ���ܹ���
    public static String decrypt(String c, String k1, String k2) {
        // ִ�г�ʼ�û�
        c = permute(c, IP);
        // �������� Fk����
        String r2 = c.substring(0, 4);
        String l2 = c.substring(4);
        // ��һ�ֵ� P4
        String fResult = F(l2, k2, EP, sbox0, sbox1, P4);
        // p4 �� R2 ���
        String l1 = String.format("%4s", Integer.toBinaryString(Integer.parseInt(r2, 2) ^ Integer.parseInt(fResult, 2))).replace(' ', '0');
        // �ڶ��ֵ� P4
        fResult = F(l1, k1, EP, sbox0, sbox1, P4);
        // p4 �� R1 ���
        String r1 = String.format("%4s", Integer.toBinaryString(Integer.parseInt(l2, 2) ^ Integer.parseInt(fResult, 2))).replace(' ', '0');
        // ���û�����������
        return permute(r1 + l1, IP_inverse);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new SDESGUI().setVisible(true);
            }
        });
    }
}