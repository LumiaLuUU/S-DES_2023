package SDESImp;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
public class BruteForce extends JFrame {
    private final JTextField plaintextField;
    private final JTextField ciphertextField;
    private final JTextArea possibleKeysArea;//��Կ�ı���
    private final JTextField timeTextField; // ����ʱ���ı���
    public BruteForce() {
        setTitle("�����Կ");
        setSize(700, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(true);
        // �������
        JLabel plaintextLabel = new JLabel("����������:");
        JLabel ciphertextLabel = new JLabel("����������:");
        JLabel possibleKeysLabel = new JLabel("���ܵ���Կ:");
        JLabel timeTextLabel = new JLabel("���ѵ�ʱ��:");

        Font labelFont = new Font(Font.DIALOG, Font.BOLD, 15);
        plaintextLabel.setFont(labelFont);
        plaintextLabel.setForeground(Color.WHITE);
        ciphertextLabel.setFont(labelFont);
        ciphertextLabel.setForeground(Color.WHITE);
        possibleKeysLabel.setFont(labelFont);
        possibleKeysLabel.setForeground(Color.WHITE);
        timeTextLabel.setFont(labelFont);
        timeTextLabel.setForeground(Color.WHITE);

        ciphertextField = new JTextField(30);
        plaintextField = new JTextField(30);
        possibleKeysArea = new JTextArea(10, 20);
        possibleKeysArea.setEditable(false);
        possibleKeysArea.setBackground(Color.decode("#7041FE"));
        possibleKeysArea.setForeground(Color.WHITE);
        possibleKeysArea.setFont(new Font(Font.DIALOG, Font.BOLD, 13)); // ���������С����ʽ

        JScrollPane possibleKeysScrollPane = new JScrollPane(possibleKeysArea);
        possibleKeysScrollPane.setBorder(BorderFactory.createEmptyBorder()); // ȥ���߿�
        Font textFieldFont = new Font(Font.DIALOG, Font.BOLD, 15);
        ciphertextField.setFont(textFieldFont);
        ciphertextField.setBackground(Color.decode("#7041FE"));
        ciphertextField.setForeground(Color.WHITE);
        plaintextField.setFont(textFieldFont);
        plaintextField.setBackground(Color.decode("#7041FE"));
        plaintextField.setForeground(Color.WHITE);

        JButton crackButton = new JButton("�����ƽ�");
        Font buttonFont = new Font(Font.DIALOG, Font.BOLD, 13);
        crackButton.setFont(buttonFont);
        crackButton.setForeground(Color.white);
        crackButton.setBackground(Color.decode("#7041FE"));

        timeTextField = new JTextField(10);
        timeTextField.setEditable(false);
        timeTextField.setBackground(Color.decode("#7041FE"));
        timeTextField.setForeground(Color.WHITE);
        timeTextField.setFont(textFieldFont);

        // ���������������
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.anchor = GridBagConstraints.NORTHWEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.gridx = 0;
        gbc.gridy = 0;
        add(plaintextLabel, gbc);
        gbc.gridy = 1;
        add(ciphertextLabel, gbc);
        gbc.gridy = 2;
        add(possibleKeysLabel, gbc);
        gbc.gridy = 8;
        add(timeTextLabel, gbc);
        gbc.gridx = 1;
        gbc.gridy = 0;
        add(plaintextField, gbc);
        gbc.gridy = 1;
        add(ciphertextField, gbc);
        gbc.gridy = 2;
        gbc.gridheight = 5;
        add(possibleKeysScrollPane, gbc);
        gbc.gridy = 8;
        gbc.gridheight = 1;
        gbc.gridwidth = 1;
        add(timeTextField, gbc);
        gbc.gridy = 9;
        gbc.gridwidth = 2;
        add(crackButton, gbc);
        // ���ô��ڱ�����ɫ
        getContentPane().setBackground(Color.decode("#161E29"));
        // ���Ӱ�ť���¼�������
        crackButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    // ��ȡ��������ĺ�����
                    String plaintext = plaintextField.getText();
                    String ciphertext = ciphertextField.getText();
                    // ȷ����������ĺ������ǺϷ��Ķ���������
                    if (!plaintext.matches("[01]+") || !ciphertext.matches("[01]+")) {
                        throw new IllegalArgumentException("���ĺ�����������ֻ����0��1�Ķ��������֡�");
                    }
                    if (plaintext.length() != 8 || ciphertext.length() != 8) {
                        throw new IllegalArgumentException("���ĺ����ı���Ϊ8λ");
                    }
                    // �����̳߳�
                    ExecutorService executor = Executors.newFixedThreadPool(4);
                    // �洢���ܵ���Կ
                    List<String> possibleKeys = Collections.synchronizedList(new ArrayList<>());
                    // ���㱩��������õ�ʱ��
                    long startTime = System.currentTimeMillis();
                    for (int i = 0; i < 1024; i++) {
                        final int index = i;
                        executor.execute(new Runnable() {
                            @Override
                            public void run() {
                                String key = String.format("%10s", Integer.toBinaryString(index)).replace(' ', '0');
                                String[] keys = SDESGUI.generateKey(key, SDESGUI.P10, SDESGUI.P8);
                                String k1 = keys[0];
                                String k2 = keys[1];
                                String guessedPlaintext = SDESGUI.decrypt(ciphertext, k1, k2);
                                if (guessedPlaintext.equals(plaintext)) {
                                    possibleKeys.add(key);
                                }
                            }
                        });
                    }
                    long endTime = System.currentTimeMillis();
                    executor.shutdown();
                    executor.awaitTermination(Long.MAX_VALUE, TimeUnit.NANOSECONDS);
                    // �����ܵ���Կ������ı���
                    StringBuilder keysStringBuilder = new StringBuilder();
                    for (String key : possibleKeys) {
                        keysStringBuilder.append(key).append("\n");
                    }
                    possibleKeysArea.setText(keysStringBuilder.toString());
                    long timeElapsed = endTime - startTime;
                    String formattedTime = String.format("%.3f", (double) timeElapsed); // ��ʱ���ת��Ϊ�룬��������λС��
                    timeTextField.setText("���������ʱ��" + formattedTime + " ����");
                } catch (IllegalArgumentException | InterruptedException ex) {
                    JOptionPane.showMessageDialog(BruteForce.this, ex.getMessage(), "����", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        // ȥ��JTextField��JButton��JTextArea�ı߿�
        plaintextField.setBorder(BorderFactory.createEmptyBorder());
        ciphertextField.setBorder(BorderFactory.createEmptyBorder());
        timeTextField.setBorder(BorderFactory.createEmptyBorder());
        possibleKeysArea.setBorder(BorderFactory.createEmptyBorder());
        crackButton.setBorder(BorderFactory.createEmptyBorder());
    }
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new BruteForce().setVisible(true);
            }
        });
    }
}