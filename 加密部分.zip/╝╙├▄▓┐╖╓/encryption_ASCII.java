import java.util.Arrays;
import java.util.Scanner;
public class encryption_ASCII {
    public static int[] IP = new int[] {2,6,3,1,4,8,5,7};
    public static int[] IP_1 = new int[] {4,1,3,5,7,2,8,6};
    public static int[] EPBox = new int[] {4,1,2,3,2,3,4,1};
    public static int[] SPBox = new int[] {2,4,3,1};
    public static int[][] SBox1 = new int[][] {{1,0,3,2},{3,2,1,0},{0,2,1,3},{3,1,0,2}};
    public static int[][] SBox2 = new int[][] {{0,1,2,3},{2,3,1,0},{3,0,1,2},{2,1,0,3}};
    public static int[] P8 = new int[] {6,3,7,4,8,5,10,9};
    public static int[] P10 = new int[] {3,5,2,7,4,10,1,9,8,6};
    public static int m = 10;

    //测试用例
    /*public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("请输入所要加密的明文：");
        if (scanner.hasNextInt()) {
            int P = scanner.nextInt();
            encryptNum(P);
        } else {
            String P = scanner.nextLine();
            encryptASCII(P);
        }
    }*/

    //二进制数据加密
    public static void encryptNum(int P){
        Scanner scanner = new Scanner(System.in);
        System.out.println("输入的是整数：" + P);
        System.out.print("请输入加密的密钥（10位数字）：");
        int K = scanner.nextInt();

        int[] Cipher= encrypt(P,K);
        System.out.print("加密后的密文为：");

        for(int i=0;i<8;i++) {
            System.out.print(Cipher[i]);
        }
        System.out.println();
    }

    //字符串加密
    public static String encryptASCII(String P,String K){
        Scanner scanner = new Scanner(System.in);
        int key = Integer.parseInt(K);

        int[] binaryArray=stringToBinaryArray(P);
        int[][] encryptedArray = new int[binaryArray.length][8];
        for (int i = 0; i < binaryArray.length; i++) {
            encryptedArray[i] = encrypt(binaryArray[i], key); // 加密二进制数组

        }
        String[] binaryStrings = convertToBinaryStrings(encryptedArray);

        String[] characters = convertToCharacters(encryptedArray);
        System.out.println(Arrays.toString(characters));
        for(int i=0;i<binaryStrings.length;i++) {
            ui_ASCII.cypher = ui_ASCII.cypher + binaryStrings[i]+',';
        }
        for(int i=0;i<characters.length;i++) {
            ui_ASCII.ASCII = ui_ASCII.ASCII + characters[i]+',';
        }
        System.out.println(ui_ASCII.cypher);
        return ui_ASCII.cypher;
    }

    //将二维数组转换为字符数组
    public static String[] convertToCharacters(int[][] encryptedArray) {
        String[] characters = new String[encryptedArray.length]; // 创建一个与加密数组长度相同的字符串数组

        for (int i = 0; i < encryptedArray.length; i++) {
            int decimal = binaryArrayToDecimal(encryptedArray[i]); // 将二进制数组转换为十进制数
            characters[i] = String.valueOf((char) decimal); // 将十进制数转换为对应的字符，并存储到字符数组中
        }
        return characters; // 返回字符数组
    }
    //二进制转十进制
    public static int binaryArrayToDecimal(int[] binaryArray) {
        int decimal = 0; // 初始化十进制数为0

        for (int i = 0; i < binaryArray.length; i++) {
            decimal = decimal * 2 + binaryArray[i]; // 将二进制数转换为十进制数
        }

        return decimal; // 返回十进制数
    }
    //转化为十进制数组
    public static int[] stringToBinaryArray(String str) {
        int[] binaryArray = new int[str.length()]; // 创建一个长度为字符串长度的一维数组

        for (int i = 0; i < str.length(); i++) {
            char c = str.charAt(i); // 获取字符串中的每个字符
            int ascii = (int) c; // 获取字符的ASCII码值
            String binaryString = String.format("%8s", Integer.toBinaryString(ascii)).replace(' ', '0'); // 将ASCII码值转换为8位二进制字符串
            binaryArray[i] = Integer.parseInt(binaryString); // 将二进制字符串转换为整数，并存储到一维数组中
        }

        return binaryArray;
    }

    //将二维数组转换为二进制字符串数组

    public static String[] convertToBinaryStrings(int[][] encryptedArray) {
        String[] binaryStrings = new String[encryptedArray.length]; // 创建一个与加密数组长度相同的字符串数组

        for (int i = 0; i < encryptedArray.length; i++) {
            StringBuilder binaryString = new StringBuilder(); // 用于构建每个二进制字符串

            for (int j = 0; j < encryptedArray[i].length; j++) {
                binaryString.append(encryptedArray[i][j]); // 将每个二进制数的每个位添加到二进制字符串中
            }

            binaryStrings[i] = binaryString.toString(); // 将二进制字符串存储到字符串数组中
        }

        return binaryStrings; // 返回二进制字符串数组
    }

    //生成子密钥k1k2
    public static int[][] generateSubKeys(int K){
        int[] k1 = new int[10];
        int[] k2 = new int[10];
        int[][] keys = new int[2][]; // 创建一个包含两个秘钥的数组
        int[] k=initialKey(K);
        // 密钥扩展
        int[] d = p10(k);
        // 生成K1
        for (int i = 0; i < 4; i++) {
            k1[i] = d[i + 1];
            k1[i + 5] = d[i + 6];
        }
        k1[4] = d[0];
        k1[9] = d[5];
        int[] K1 = p8(k1);
        // 生成K2
        for (int i = 0; i < 3; i++) {
            k2[i] = d[i + 2];
            k2[i + 5] = d[i + 7];
        }
        k2[3] = d[0];
        k2[4] = d[1];
        k2[8] = d[5];
        k2[9] = d[6];
        int[] K2 = p8(k2);
        keys[0]=K1;
        keys[1]=K2;
        return keys;
    }
    //加密
    public static int[] encrypt(int P, int K){
        int[] a = new int[8];
        int[] c = new int[8];
        int[] b, F, F1;
        int[] L0 = new int[4];
        int[] R0 = new int[4];
        int[] L1 = new int[4];
        int[] R1 = new int[4];
        int[] C;

        //将整型明文输入转化为2进制数组
        for(int i=0;i<8;i++){
            a[7-i] = P%m;
            P = P/10;
        }
        // 初始置换盒
        b = ip(a);

        // 函数f(k)
        for (int i = 0; i < 4; i++) {
            L0[i] = b[i];
            R0[i] = b[i + 4];
        }
        int[][] keys = generateSubKeys(K);
        F = spBox(sBox(XOR(epBox(R0), keys[0])));

        // 与L异或
        int[] L = XOR(F, L0);

        // 左右互换
        for (int i = 0; i < 4; i++) {
            L1[i] = R0[i];
            R1[i] = L[i];
        }

        // 第二次f(k)
        F1 = spBox(sBox(XOR(epBox(R1), keys[1])));

        // 与L异或并合并
        L = XOR(F1, L1);

        for (int i = 0; i < 4; i++) {
            c[i] = L[i];
            c[i + 4] = R1[i];
        }
        // 最终置换
        C = ip_1(c);
        return C;
    }

    public static int[] p10(int x[]){
        int y[] = new int[10];
        for(int i=0;i<10;i++) {
            y[i] = x[P10[i]-1];
        }
        return y;
    }public static int[] p8(int x[]){
        int y[] = new int[8];
        for(int i=0;i<8;i++) {
            y[i] = x[P8[i]-1];
        }
        return y;
    }
    public static int[] ip(int x[]){
        int y[] = new int[8];
        for(int i=0;i<8;i++) {
            y[i] = x[IP[i]-1];
        }
        return y;
    }
    public static int[] XOR(int x[],int y[]) {
        int z[] = new int[8];
        for (int i = 0; i < x.length; i++) {
            if (x[i] == y[i]) z[i] = 0;
            if (x[i] != y[i]) z[i] = 1;
        }
        return z;
    }
    public static int[] ip_1(int x[]){
        int y[] = new int[8];
        for(int i=0;i<8;i++) {
            y[i] = x[IP_1[i]-1];
        }
        return y;
    }
    public static int[] epBox(int x[]){
        int y[] = new int[8];
        for(int i=0;i<8;i++) {
            y[i] = x[EPBox[i]-1];
        }
        return y;
    }
    public static int[] sBox(int x[]){
        int z[] = new int[4];
        int p,q,m;
        p = x[0]*2+x[3];
        q = x[1]*2+x[2];
        m = SBox1[p][q];
        if(m==0){
            z[0]=0;
            z[1]=0;
        }
        if(m==1){
            z[0]=0;
            z[1]=1;
        }
        if(m==2){
            z[0]=1;
            z[1]=0;
        }
        if(m==3){
            z[0]=1;
            z[1]=1;
        }
        p = x[4]*2+x[7];
        q = x[5]*2+x[6];
        m = SBox2[p][q];
        if(m==0){
            z[2]=0;
            z[3]=0;
        }
        if(m==1){
            z[2]=0;
            z[3]=1;
        }
        if(m==2){
            z[2]=1;
            z[3]=0;
        }
        if(m==3){
            z[2]=1;
            z[3]=1;
        }
        return z;
    }
    public static int[] spBox(int x[]){
        int y[] = new int[4];
        for(int i=0;i<4;i++) {
            y[i] = x[SPBox[i]-1];
        }
        return y;
    }

    //初始化密钥
    public static int[] initialKey(int K){
        int[] k = new int[10];
        int m = 10;
        for (int i = 0; i < 10; i++) {
            k[9 - i] = K % m;
            K = K / 10;
        }
        return k;
    }
}