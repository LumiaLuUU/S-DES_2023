import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class menu {
    JFrame frame=new JFrame("加密程序");//创建一个新的、不可见的、名为test的窗体
    JLabel label1=new JLabel("功能选择");
    JButton btn = new JButton("整数加密");
    JButton btn1 = new JButton("字符串加密");
    JPanel panel=new JPanel();
    public menu() {
        panel.setLayout(null);
        frame.setSize(500,400);//设置窗口的大小
        frame.setLocation(300, 100);
        label1.setBounds(200, 70, 150, 50);
        label1.setFont(new Font("宋体",Font.BOLD,25));
        btn.setBounds(60,180,150,50);
        btn.setFont(new Font("宋体",Font.BOLD,16));
        btn1.setBounds(270,180,150,50);
        btn1.setFont(new Font("宋体",Font.BOLD,16));

        panel.add(label1);
        panel.add(btn);
        panel.add(btn1);
        frame.add(panel);
        frame.setVisible(true);//设置窗口可见
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        btn.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e) {
                ui.main();
            }
        });
        btn1.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e) {
                ui_ASCII.main();
            }
        });
    }
    public static void main(String[] args) {
        EventQueue.invokeLater(()->{
            new menu();
        });
    }

}