import java.util.Scanner;
public class encryption {
    public static int[] IP = new int[] {2,6,3,1,4,8,5,7};
    public static int[] IP_1 = new int[] {4,1,3,5,7,2,8,6};
    public static int[] EPBox = new int[] {4,1,2,3,2,3,4,1};
    public static int[] SPBox = new int[] {2,4,3,1};
    public static int[][] SBox1 = new int[][] {{1,0,3,2},{3,2,1,0},{0,2,1,3},{3,1,0,2}};
    public static int[][] SBox2 = new int[][] {{0,1,2,3},{2,3,1,0},{3,0,1,2},{2,1,0,3}};
    public static int[] P8 = new int[] {6,3,7,4,8,5,10,9};
    public static int[] P10 = new int[] {3,5,2,7,4,10,1,9,8,6};
    public static int m = 10;
    public static String main(String x,String y) {
        int[] a = new int[8];
        int[] c = new int[8];
        int[] k = new int[10];
        int[] b,F,F1;
        int[] k1 = new int[10];
        int[] k2 = new int[10];
        int[] L0 = new int[4];
        int[] R0 = new int[4];
        int[] L1 = new int[4];
        int[] R1 = new int[4];
        int[] C;
        int P = Integer.parseInt(x);
        int K = Integer.parseInt(y);
        for(int i=0;i<8;i++){
            a[7-i] = P%m;
            P = P/10;
        }
        m = 10;
        for(int i=0;i<10;i++){
            k[9-i] = K%m;
            K = K/10;
        }
        //1.密钥扩展
        int[] d = p10(k);
        //1.1 K1
        for(int i=0;i<4;i++){
            k1[i] = d[i+1];
            k1[i+5] = d[i+6];
        }
        k1[4] = d[0];
        k1[9] = d[5];
        int[] K1 = p8(k1);
        //1.2 K2
        for(int i=0;i<3;i++){
            k2[i] = d[i+2];
            k2[i+5] = d[i+7];
        }
        k2[3] = d[0];
        k2[4] = d[1];
        k2[8] = d[5];
        k2[9] = d[6];
        int[] K2 = p8(k2);

        //2.初始置换盒
        b = ip(a);

        //3.函数f(k)
        for(int i=0;i<4;i++){
            L0[i] = b[i];
            R0[i] = b[i+4];
        }
        F = spBox(sBox(XOR(epBox(R0),K1)));

        //4.与L异或
        int[] L = XOR(F,L0);

        //5.左右互换
        for(int i=0;i<4;i++) {
            L1[i] = R0[i];
            R1[i] = L[i];
        }

        //6.第二次f(k)
        F1 = spBox(sBox(XOR(epBox(R1),K2)));

        //7.与L异或并合并
        L = XOR(F1,L1);
        for(int i=0; i<4; i++){
            c[i] = L[i];
            c[i+4] = R1[i];
        }
        //8.最终置换
        C = ip_1(c);

        for(int i=0;i<8;i++) {
            String z =Integer.toString(C[i]) ;
            ui.cypher = ui.cypher + z;
        }
        System.out.println(ui.cypher);
        return ui.cypher;
    }
    public static int[] p10(int x[]){
        int y[] = new int[10];
        for(int i=0;i<10;i++) {
            y[i] = x[P10[i]-1];
        }
        return y;
    }public static int[] p8(int x[]){
        int y[] = new int[8];
        for(int i=0;i<8;i++) {
            y[i] = x[P8[i]-1];
        }
        return y;
    }
    public static int[] ip(int x[]){
        int y[] = new int[8];
        for(int i=0;i<8;i++) {
            y[i] = x[IP[i]-1];
        }
        return y;
    }
    public static int[] XOR(int x[],int y[]) {
        int z[] = new int[8];
        for (int i = 0; i < x.length; i++) {
            if (x[i] == y[i]) z[i] = 0;
            if (x[i] != y[i]) z[i] = 1;
        }
        return z;
    }
    public static int[] ip_1(int x[]){
        int y[] = new int[8];
        for(int i=0;i<8;i++) {
            y[i] = x[IP_1[i]-1];
        }
        return y;
    }
    public static int[] epBox(int x[]){
        int y[] = new int[8];
        for(int i=0;i<8;i++) {
            y[i] = x[EPBox[i]-1];
        }
        return y;
    }
    public static int[] sBox(int x[]){
        int z[] = new int[4];
        int p,q,m;
        p = x[0]*2+x[3];
        q = x[1]*2+x[2];
        m = SBox1[p][q];
        if(m==0){
            z[0]=0;
            z[1]=0;
        }
        if(m==1){
            z[0]=0;
            z[1]=1;
        }
        if(m==2){
            z[0]=1;
            z[1]=0;
        }
        if(m==3){
            z[0]=1;
            z[1]=1;
        }
        p = x[4]*2+x[7];
        q = x[5]*2+x[6];
        m = SBox2[p][q];
        if(m==0){
            z[2]=0;
            z[3]=0;
        }
        if(m==1){
            z[2]=0;
            z[3]=1;
        }
        if(m==2){
            z[2]=1;
            z[3]=0;
        }
        if(m==3){
            z[2]=1;
            z[3]=1;
        }
        return z;
    }
    public static int[] spBox(int x[]){
        int y[] = new int[4];
        for(int i=0;i<4;i++) {
            y[i] = x[SPBox[i]-1];
        }
        return y;
    }
}