import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class ui_ASCII {
    public static String cypher="";
    public static String ASCII="";
    JFrame frame=new JFrame("字符串加密程序");//创建一个新的、不可见的、名为test的窗体
    JLabel label1=new JLabel("输入明文");
    JLabel label2=new JLabel("输入密钥");
    JTextField f1=new JTextField();
    JTextField f2=new JTextField();
    JButton btn = new JButton("进行加密");
    JPanel panel=new JPanel();
    public ui_ASCII() {
        panel.setLayout(null);
        frame.setSize(500,500);//设置窗口的大小
        frame.setLocation(300, 100);
        label1.setBounds(90, 60, 80, 40);
        label1.setFont(new Font("宋体",Font.BOLD,14));
        f1.setBounds(180, 60, 200, 40);
        label2.setBounds(90,150,80,40);
        label2.setFont(new Font("宋体",Font.BOLD,14));
        f2.setBounds(180, 150, 200, 40);
        btn.setBounds(160,240,180,40);
        btn.setFont(new Font("宋体",Font.BOLD,16));

        panel.add(label1);
        panel.add(label2);
        panel.add(f1);
        panel.add(f2);
        panel.add(btn);
        frame.add(panel);
        frame.setVisible(true);//设置窗口可见
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        btn.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e) {
                String P =f1.getText();
                String K =f2.getText();
                if(K.length()!=10)
                    JOptionPane.showMessageDialog(frame,"输入的密钥需为10位","报错提示",1);
                cypher = encryption_ASCII.encryptASCII(P,K);
                JOptionPane.showMessageDialog(frame,"本次加密的密文为：\n    "+cypher+"\n本次加密的ASCII码为：\n    "+ASCII,"加密输出",-1);
            }
        });
    }
    public static void main() {
        EventQueue.invokeLater(()->{
            new ui_ASCII();
        });
    }

}